import 'dart:math';
import 'package:flutter/material.dart';

class JogoAdivinha extends StatefulWidget {
  @override
  _JogoAdivinhaState createState() => _JogoAdivinhaState();
}

class _JogoAdivinhaState extends State<JogoAdivinha> {
  // VARIAVEIS
  final _tNumero = TextEditingController();
  var _infoText = "Tente adivinhar o número gerado aleatoriamente!";
  var _formKey = GlobalKey<FormState>();
  Random random = new Random();
  int numero;
  int tentativas = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Adivinhe o numero"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.refresh), onPressed: _resetFields)
        ],
      ),
      body: _body(),
    );
  }

  // PROCEDIMENTO PARA LIMPAR OS CAMPOS
  void _resetFields() {
    _tNumero.text = "";
    numero = _novoNumero();
    tentativas = 0;
    setState(() {
      _infoText = "Tente adivinhar o número gerado aleatoriamente!";
      _formKey = GlobalKey<FormState>();
    });
  }

  _body() {
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editText("Número:", _tNumero),
              _buttonCalcular(),
              _textInfo(),
            ],
          ),
        ));
  }

  // Widget text
  _editText(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.greenAccent[500],
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  // PROCEDIMENTO PARA VALIDAR OS CAMPOS
  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  // Widget button
  _buttonCalcular() {
    return Container(
      margin: EdgeInsets.only(top: 10.0, bottom: 20),
      height: 45,
      child: RaisedButton(
        color: Colors.greenAccent[500],
        child: Text(
          "Conferir",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if (_formKey.currentState.validate()) {
            _confere();
          }
        },
      ),
    );
  }

  void _confere() {
    if (numero == null) numero = _novoNumero();
    setState(() {
      if (int.parse(_tNumero.text) == numero) {
        _infoText = "Acertou em " +
            tentativas.toString() +
            " tentativas!\nUm novo numero secreto foi gerado!";
        numero = _novoNumero();
        tentativas = 0;
      } else {
        tentativas++;

        if (int.parse(_tNumero.text) > 50 || int.parse(_tNumero.text) < 0) {
          _infoText = "O numero secreto está entre 0 e 50!";
        } else if (int.parse(_tNumero.text) > numero) {
          _infoText = "Quase! o número é menor que " + _tNumero.text + "!";
        } else {
          _infoText = "Quase! o número é MAIOR que " + _tNumero.text + "!";
        }
      }
    });
  }

  int _novoNumero() {
    return random.nextInt(51);
  }

  // // Widget text
  _textInfo() {
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.green[500], fontSize: 25.0),
    );
  }
}
