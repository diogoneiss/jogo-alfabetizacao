import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class JogoDoAdivinha extends StatefulWidget {
  @override
  _JogoDoAdivinhaState createState() => _JogoDoAdivinhaState();
}

class _JogoDoAdivinhaState extends State<JogoDoAdivinha> {
  int numero;
  int numeroDeTentativas = 0;

  @override
  Widget build(BuildContext context) {
    var ranGenerator = Random();
    numero = ranGenerator.nextInt(100);

    return new Scaffold(
      backgroundColor: Colors.white,
      body: new Container(
          padding: const EdgeInsets.all(40.0),
          child: new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new TextField(
                decoration:
                    new InputDecoration(labelText: "Insira o número abaixo"),
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ], // Only numbers can be entered
              ),
            ],
          )),
    );
  }

  String guess(int numAdivinhado) {
    String textoFeedback;

    //ler num adivinhado

    if (numAdivinhado > this.numero) {
      textoFeedback = "O número é MENOR que o digitado";
    } else if (numAdivinhado < this.numero) {
      textoFeedback = "O número é MAIOR que o digitado";
    } else {
      textoFeedback = "Acertou!";
    }

    return textoFeedback;
  }
}
